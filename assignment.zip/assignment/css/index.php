<?php
    header("Location: https://kdupg-newsletter.000webhostapp.com/assignment/php/home.php");
?>